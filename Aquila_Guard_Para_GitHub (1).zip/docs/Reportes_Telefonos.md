# Reportes compartidos de teléfonos

En Aquila Guard Web, abre **Revisar → Teléfono** e ingresa el número completo con su código internacional. **Revisar ahora** comprueba el formato localmente. **Consultar reportes compartidos** requiere internet y una cuenta con correo verificado. Cada usuario usa su propia cuenta. El mismo número consulta la misma ficha desde distintos equipos.

## Reportar una llamada o un SMS

1. Con una cuenta verificada, escribe el número y abre **Reportar una llamada o SMS sospechoso**.
2. Selecciona qué ocurrió y si el número apareció como identificador de llamada, remitente de SMS o destino al que pedían llamar. Pulsa **Enviar reporte para revisión**.
3. La app confirma que el equipo recibió el reporte. Un mismo número se registra una vez por cuenta. Para consultar el estado, vuelve a elegir el número y pulsa el botón de envío.

Los envíos quedan en `users/{uid}/phoneTips/{key}`. La persona que envió el reporte puede recuperar su estado. El registro contiene la huella como ID, la categoría, el origen y la fecha. El teléfono se normaliza y se convierte en huella en el navegador antes de enviar el reporte. Otros usuarios carecen de acceso a esos datos. Se admite un envío nuevo cada diez minutos por cuenta verificada.

## Publicar y probar

1. Ejecuta `Publicar_Aquila_Guard.cmd` y autoriza Firebase con una cuenta administradora del proyecto. El lanzador prepara la web, crea una ficha ficticia y publica Hosting y las reglas de Firestore.
2. En **Revisar → Teléfono**, pulsa **Cargar número ficticio** y después **Consultar reportes compartidos**. El resultado esperado es **Caso ficticio de demostración**. El número `+1 202 555 0147` está en el rango ficticio reservado por NANPA. [NANPA](https://nanpa.com/numbering/555-line-numbers)
3. Repite en otro navegador con otra cuenta verificada. Prueba luego `+1 202 555 0148` tras seis segundos. El resultado esperado para el segundo número es **Sin reporte vigente** si nadie creó una ficha para él.

## Fichas y evidencia

Solo un administrador de Firestore puede activar, corregir o retirar una coincidencia. Comprueba la evidencia con una fuente oficial obtenida por separado. Calcula localmente la huella del número que documenta la fuente y contrástala con el ID del reporte. Distingue el número al que pedían llamar del identificador mostrado. Si no existe evidencia que puedas comprobar, conserva el estado pendiente o marca `declined`.

Para vincular un aviso privado, busca su documento en **Firestore Database → Datos**, dentro de la subcolección `phoneTips` del usuario. Si se puede respaldar, crea primero el registro privado de vigencia y después el marcador de consulta con el mismo ID. Cambia `status` del reporte original a `approved`. Retira los marcadores caducados y los que requieran una corrección. Conserva los avisos originales durante el tiempo necesario para la revisión y las correcciones.

El identificador se calcula con `AquilaCloud.phoneReportKey` de `shared/cloud.js`. Usa las dos colecciones siguientes con ese mismo ID.

- `phoneReportEvidence/{key}` contiene `status` como `reviewed`, `expiresAt` como timestamp y los datos mínimos de la revisión. Evita guardar nombres, números en texto libre y copias de mensajes. El acceso es administrativo.
- `phoneReports/{key}` contiene solo `status: reviewed`. El caso ficticio usa `status: demo` en ambos documentos. El publicador los prepara juntos. Una consulta ordinaria devuelve la coincidencia, la ausencia de un reporte o un error de disponibilidad.

Si se llegó a publicar la beta anterior y ya existen reportes, revisa las colecciones antes de reutilizarlas. Quita el campo `number` de los avisos en `phoneTips`. En las fichas anteriores, mueve los detalles que necesites conservar a `phoneReportEvidence` y deja solo `status` en `phoneReports`. Las reglas nuevas bloquean la lectura desde la app de los documentos con el esquema anterior. El publicador convierte automáticamente solo la ficha ficticia.

La identidad del llamante puede falsificarse. La FTC publica denuncias sin verificar y PhishDestroy suministra dominios. Esas fuentes no se importan como acusaciones contra números telefónicos. [FTC sobre suplantación](https://consumer.ftc.gov/consumer-alerts/2016/05/scammers-can-fake-caller-id-info) · [Datos de la FTC](https://search.ftc.gov/policy-notices/open-government/data-sets/do-not-call-data) · [PhishDestroy](https://phishdestroy.io/dataset)

## Acceso y privacidad

La app envía una huella SHA-256 del número normalizado. Las huellas deterministas de teléfonos pueden cotejarse con números probables. Firestore limita la búsqueda a un identificador por permiso, con una pausa de seis segundos, un máximo de 20 permisos por cuenta en 24 horas y una vigencia de 15 segundos por permiso. El usuario no puede listar fichas, publicar reportes ni leer permisos de otra cuenta. Estos controles reducen la enumeración y consumen las cuotas del plan Spark. Un atacante con múltiples cuentas todavía puede intentar búsquedas.

Cada cuenta conserva un solo registro de control con última huella, contador y fechas. Se reemplaza al consultar de nuevo. El administrador puede eliminarlo a solicitud del titular. El historial personal es independiente.
